# Changelog

### [PROXIMA RELEASE]

### Adiciona 10/02/2022
- [CART_ADM-534](https://anbima.myjetbrains.com/youtrack/issue/CART_ADM-534) Provisionamento Lambda
